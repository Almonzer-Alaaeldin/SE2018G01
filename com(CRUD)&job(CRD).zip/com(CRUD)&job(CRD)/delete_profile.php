<?php require_once "company.php";?>
<?php
$email = $_POST['Email'];
company::delete($email);
header('Location: main.php'); 
?>