<?php require_once "job.php"?>
<?php
$position=$_POST['position'];
$requirements=$_POST['requirements'];
$selection=$_POST['selection'];
job::create($position,$requirements,$selection,13); //account_id var instead of 13
header('Location: view profile.php');
?>