<?php require_once "service_web_database.php"; ?>
<?php 
class job {
    function __construct($id){
        global $db;
        $sql="SELECT * FROM jobs WHERE id='$id';";
        $statement=$db->prepare($sql);
        $statement->execute();
        $data=$statement->fetch(PDO::FETCH_ASSOC);
        foreach ($data as $key=>$value){
    $this->{$key}=$value;
        }
    }
    

public function create($position,$requirements,$selection,$account_id){
    global $db;
$query = "INSERT INTO jobs (position,requirement,selection_phase,account_id) VALUES ('$position','$requirements','$selection','$account_id'); "; 
$statement=$db->prepare($query);
$statement->execute();
}

public function get_jobs_row_using_acc_id ($account_id){
    global $db;
    $query = "SELECT id  FROM jobs WHERE account_id='$account_id'"; 
    $statement=$db->prepare($query);
    $statement->execute();
    while($row = $statement->fetch(PDO::FETCH_ASSOC)) {
        $jobs[] = new job($row['id']);
    }
    return $jobs;
}

public function delete() {
    global $db;
    $sql = "DELETE FROM jobs WHERE id=$this->id;";
    $db->query($sql);
}




};








?>