<?php require_once "job.php" ?>

<?php
$job=new job($_GET['id']);
$job->delete();
header('Location: view_jobs.php');

?>