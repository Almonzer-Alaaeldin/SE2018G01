<div class="container">
  <div class="modal fade" id="add-job-modal" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title" >Add Job</h4> 
          <button type="button" class="btn" data-dismiss="modal">X</button>
        </div>
        <div class="modal-body">
	<form action="save_job.php" method="post" id="make-report-form">		
<div class="r"><h6>Position:</h6><input type="text" name="position" style="width: 300px;" required="required"></div>
<div class="r"><h6>Requirements:</h6></td><td><textarea type="text" name="requirements" style="width: 300px;" required="required"></textarea> </div>
<div class="r"><h6>selection phases:</h6></td><td><textarea type="text" name="selection" style="width: 300px;" required="required"></textarea> </div>
  <div class="text-center r"><button type="submit" class="btn btn-primary" name="submit" >Add Job</button></div>
  </form>
	</div>
        </div>
        <div class="modal-footer">
     
      
        <!--  <button type="button" class="btn btn-danger" data-dismiss="modal">x</button> -->
        </div>
      </div>
      </div>
    </div>
    


    <div class="container">
  <div class="modal fade" id="delete-profile-modal" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title" >Enter Your Email to Delete profile </h4> 
          <button type="button" class="btn" data-dismiss="modal">X</button>
        </div>
        <div class="modal-body">
	<form action="delete_profile.php" method="post" id="make-report-form">		
<div class="r"><h6>Email:</h6><input type="text" name="Email" style="width: 300px;" required="required"></div>
  <div class="text-center r"><button type="submit" class="btn btn-primary" name="submit" >Delete Profile</button></div>
  </form>
	</div>
        </div>
        <div class="modal-footer">
        </div>
      </div>
      </div>
    </div>
    