<?php require_once "company.php" ?>

<?php
$name=$_POST['name'];
$mission=$_POST['mission'];
$vision=$_POST['vision'];
$brief=$_POST['brief'];
company::edit_profile($name,$mission,$vision,$brief,14);
header('Location: view profile.php');   // account_id is required to view same profile i put it = 13
?>
