<?php require_once "header.php"; ?>
<?php require_once "job.php"; ?>
<?php require_once "nav.php"; ?>

<style>

table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    margin-top: 15px;
    text-align: center;
    width: 100%;
    margin-bottom: 30px;
}

td, th {
    border: none;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color:#dddddd; 
  }

  a{
	text-underline-position: none;
	color: white;
}

a:hover {
    text-decoration: none;
    color: white;
}

button {
	 background-color: black;
    color: white;
    margin: 8px 0;
    border: 2px solid black;
    border-radius: 15px;
    padding: 8px 8px;
    cursor: pointer;


}

</style>

<div class="row"  id="jobs" style="margin-bottom:10px;">
		<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2"><h1> </h1></div>
	<div class="col-xs-8 col-sm-8 col-md-8 col-lg-8">	
<table>
	 <tr>
    
    <th>Position</th>
    <th>Requirements</th>
    <th>Selecetion Phases</th>
  
  </tr>
	<?php
$jobs=job::get_jobs_row_using_acc_id (13);  //enter account_id var instead of 13
	foreach ($jobs as $job) {
		?>
		<tr><td><?= $job->position ?></td> <td><?=$job->requirement?></td> <td><?=$job->selection_phase?></td>
    <td><button style="float: right;"><a href="delete_job.php?id=<?=$job->id?>">Delete</a></button></td></tr>  
		<?php
	}
	?>
</table>
		
	</div>

	<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2"><h1> </h1></div>
	
</div>

































<?php require_once "footer.php"; ?>