<?php
if(isset($_POST['edit-profile'])){
    header('Location: edit_profile.php');
}

if(isset($_POST['delete-profile'])){
    header('Location: school.php');

}
    if(isset($_POST['add-job'])){
        header('Location: add_job.php');
    }
        if(isset($_POST['hire-dev'])){
            header('Location: hire_dev.php');
        }





?>