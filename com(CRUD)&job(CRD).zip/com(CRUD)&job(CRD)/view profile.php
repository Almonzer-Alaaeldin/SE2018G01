<?php require_once "header.php"; ?>
<?php require_once "nav.php"; ?>
<?php require_once "company.php"; ?>
<?php  require_once "modals.php"; ?>
<?php $row=company::get_company_row_using_acc_id(13); ?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>profile</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
   <link rel="stylesheet" type="text/css" href="company profile.css">
</head>
<style>
.r{
    margin-top: 1rem;
}
</style>


<div class="container emp-profile">
            <form method="post">
                <div class="row text-center">
                    <div class="col-md-4">
                <div class="btns">
                       <button   class="profile-btn"> <a style="color:gray;" href="edit_profile_form.php"   >Edit Profile</a></button> <br>
                     <!--  <button   class="profile-btn"> <a style="color:gray;" href="delete_profile.php" >Delete Profile</a></button> <br> -->
                       <button   class="profile-btn">  <a  data-toggle="modal" data-target="#delete-profile-modal">Delete Profile</a></button> <br>
                       <button   class="profile-btn"> <a style="color:gray;" href="hire_dev.php"       >Hire Developer</a></button> <br>
                       <button   class="profile-btn"> <a style="color:gray;" href="view_jobs.php"       >View Jobs</a></button> <br>
                       <button   class="profile-btn">  <a  data-toggle="modal" data-target="#add-job-modal">Add Job</a></button> <br>
                </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="profile-head text-center">
                                    <h1 id="demo">
                                        <?php echo $row['name']; ?>
                                    </h1>
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Vision</a>
                                </li>
                                 <div> <p> <?php echo $row['vision']; ?></div> 
                            </ul>
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Mission</a>
                                </li>
                                <p><?php echo $row['mission']; ?></p>
                            </ul>
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Breif</a>
                                </li>
                                <p><?php echo $row['brief'] ;?></p>
                           
                        </div>
                    </div>
                    <div class="col-md-2">
                       
                    </div>
                </div>
              
            </form>           
        </div>

        <?php require_once "footer.php"; ?>