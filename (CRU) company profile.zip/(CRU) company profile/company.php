<?php
require_once "service_web_database.php";
class company {
    //global for each function 
    public function create_account_profile($name,$mission,$vision,$brief,$email,$password_hash){
        global $db;
        $company='company';
        $qurey_create_acc ="INSERT INTO accounts (email,password_hash,type) VALUES ('$email','$password_hash','$company');";
        $statement= $db->prepare($qurey_create_acc);
        if($db->exec($qurey_create_acc)){
        $account_id = $db->lastInsertId();
        $qurey_create_com ="INSERT INTO companies(name,mission,vision,brief,account_id) VALUES ('$name','$mission','$vision','$brief','$account_id');";
        $statement= $db->prepare($qurey_create_com);
        $statement->execute();
    }
    }
    
    public function get_company_row_using_acc_id($account_id){
             global $db;
            $statement =$db->prepare("SELECT DISTINCT * FROM accounts JOIN companies ON (companies.account_id='$account_id' and accounts.id='$account_id');");
            $statement->execute();
            $row = $statement->fetch(PDO::FETCH_ASSOC) ;  
                return $row;  
    }

    public function edit_profile($name,$mission,$vision,$brief,$account_id){
        global $db;
        $query_update="UPDATE companies SET name='$name', vision='$vision' , mission='$mission', brief='$brief' WHERE companies.account_id='$account_id'; ";
        $statement= $db->prepare($query_update); 
        $statement->execute();
    }

    public function add_job(){
        global $db;
        
    }

    




/*public function delete(){
global $db ; 
$query_delete="DELETE FROM companies WHERE id=$this->id;"
}*/




};



?>