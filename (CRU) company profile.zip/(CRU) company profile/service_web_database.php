 
<?php
$database= "service_web_database";
try {
$db=new PDO ('mysql:host=localhost;dbname=service_web_database','root','123456');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
echo "connected";

}

catch(PDOException $e) 
{
	$e->getMessage();

}






?>


