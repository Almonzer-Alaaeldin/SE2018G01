<div class="container">
  <div class="modal fade" id="add-job-modal" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title" >Report an issue</h4> <button type="button" class="btn btn-danger" data-dismiss="modal">x</button>
        </div>
        <div class="modal-body">
	<form action="save_report.php" method="post" id="make-report-form">		
<div><h6>Title:</h6></td><td><input type="text" name="title" style="width: 300px;"></div>
<div><h6>Content:</h6></td><td><textarea type="text" name="content" style="width: 300px;"> </div>
	</form>

	</div>
        </div>
        <div class="modal-footer">
        <button type="button"class="btn btn-primary" name="ReportButton"><a href="save_report.php" style="color:white;">Report </a></button>
        <!--  <button type="button" class="btn btn-danger" data-dismiss="modal">x</button> -->
        </div>
      </div>
      </div>
    </div>
 