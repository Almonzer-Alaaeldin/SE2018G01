<div class="jumbotron text-center" style="margin-bottom: 0; padding: 0px 0px 0px 0px; background-color: lavender">
      <div id="ImgSlide" class="carousel slide" data-ride="carousel">

      <ul class="carousel-indicators">
        <li data-target="#ImgSlide" data-slide-to="0"></li>
        <li data-target="#ImgSlide" data-slide-to="1" class="active"></li>
        <li data-target="#ImgSlide" data-slide-to="2"></li>
      </ul>

      <div class="carousel-inner">
        <div class="carousel-item">
          <img src="Images/Dev1.jpg" alt="Devs" style="height: 400px; width: 100%; filter: blur(3px) contrast(0.5); ">
           	<div class="carousel-caption">
        		<h1 style="color: black;">Developers</h1>
        		<p style="color: black;">Become a developer</p>
      		</div>
        </div>
        <div class="carousel-item  active">
          <img src="Images/office4.jpg" alt="Bussiness" style="height: 400px; width: 100%; filter: blur(2px) contrast(0.5);">
            <div class="carousel-caption">
        		<h1 style="color: black;">Bussiness</h1>
        		<p style="color: black;">Some bussiness</p>
      		</div>
        </div>
        <div class="carousel-item">
          <img src="Images/Enter1.jpg" alt="Enterpenurship" style="height: 400px; width: 100%; filter: blur(1px) contrast(0.5);">
            <div class="carousel-caption">
        		<h1 style="color: black;">Enterpenurship</h1>
        		<p style="color: black;">Kickstart your bussiness</p>
      		</div>
        </div>
      </div>

      <a class="carousel-control-prev" href="#ImgSlide" data-slide="prev">
        <span class="carousel-control-prev-icon"></span>
      </a>
      <a class="carousel-control-next" href="#ImgSlide" data-slide="next">
        <span class="carousel-control-next-icon"></span>
      </a>

    </div>
    </div>