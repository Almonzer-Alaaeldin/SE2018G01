<?php require_once "header.php"; ?>
<?php require_once "nav.php"; ?>
<?php require_once "create_com_form.php"; ?>
<?php require_once "footer.php"; ?>
<?php require_once "service_web_database.php"  ;  ?>


