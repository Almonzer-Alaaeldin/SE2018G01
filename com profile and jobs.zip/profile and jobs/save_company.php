<?php 
require_once "company.php";
if ($_POST['password']==$_POST['Repeatpassword']){
    $password_hash=password_hash($_POST['password'],PASSWORD_DEFAULT);
    //$acc_id=company::get_account_id_of_this_email($_POST['Email']);
    company::create_account_profile($_POST['name'],$_POST['mission'],$_POST['vision'],$_POST['brief'],$_POST['Email'],$password_hash);
    
  //  company::create_profile($_POST['name'],$_POST['mission'],$_POST['vision'],$_POST['brief']);
}
else {echo'passwords doesnot match'; }


?>