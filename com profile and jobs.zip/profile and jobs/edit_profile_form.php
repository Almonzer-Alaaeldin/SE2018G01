<?php require_once "header.php"; ?>
<?php require_once "nav.php"; ?>
<?php require_once "service_web_database.php"  ;  ?>
<div class="container text-center">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12  text-center" > 
<div class="card bg-light">
<article class="card-body mx-auto" style="max-width: 400px;">
	<h4 class="card-title mt-3 text-center">Edit Company Profile</h4>
	<p class="text-center">fill the form below</p>
	<form action="edit_profile.php" method="post">
	<div class="form-group input-group">
		<div class="input-group-prepend">
		    <span class="input-group-text"> <i class="fa fa-user"></i> </span>
		 </div>
        <input name="name" class="form-control" placeholder="Company Name" type="text">
    </div> <!-- form-group// -->
<div class="form-group input-group">
 <div class="input-group-prepend">
   <span class="input-group-text"> <i class="fas fa-eye"></i> </span>
<textarea name="vision" rows="3" cols="40" placeholder="Vision"></textarea> </div>
</div> <!-- form-group// -->
<div class="form-group input-group">
 <div class="input-group-prepend">
   <span class="input-group-text"> <i class=" fa fa-info-circle"></i> </span>
<textarea name="mission" rows="3" cols="40" placeholder="Mission"></textarea> </div>
</div> <!-- form-group// -->
<div class="form-group input-group">
 <div class="input-group-prepend">
   <span class="input-group-text"> <i class=" fa fa-info-circle"></i> </span>

 <textarea name="brief" rows="3" cols="40" placeholder="Brief Describition"></textarea> </div>
</div> <!-- form-group// -->

    <div class="form-group text-center">
        <button name="form_submitted" type="submit" class="btn btn-primary btn-block"> Edit Profile  </button>
    </div> <!-- form-group// -->
    
    
</form>
</article>
</div> <!-- card.// -->
</div>
</div>
<!--container end.//-->
 <?php require_once "footer.php"; ?> 