<div class="jumbotron text-center" style="margin-bottom: 0; background-color: rgb(32,32,32);">
  <p style="color: white;"><span>&copy;</span> <a href="SE2018G01.ml" style="color: white;">SE2018G01.ml</a></p>
</div>