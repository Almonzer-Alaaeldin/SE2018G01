<?php
require_once "service_web_database.php";
class company {
    //global for each function 
    public function create_account_profile($name,$mission,$vision,$brief,$email,$password_hash){
        global $db;
        $company='company';
        $qurey_create_acc ="INSERT INTO accounts (email,password_hash,type) VALUES ('$email','$password_hash','$company');";
        $statement= $db->prepare($qurey_create_acc);
        if($db->exec($qurey_create_acc)){
        $account_id = $db->lastInsertId();
        $qurey_create_com ="INSERT INTO companies(name,mission,vision,brief,account_id) VALUES ('$name','$mission','$vision','$brief','$account_id');";
        $statement= $db->prepare($qurey_create_com);
        $statement->execute();
    }
    }    

    




/*public function delete(){
global $db ; 
$query_delete="DELETE FROM companies WHERE id=$this->id;"
}*/




};



?>